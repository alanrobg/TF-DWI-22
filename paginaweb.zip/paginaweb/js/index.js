$(document).ready(function()
{
    
    M.AutoInit();
    $('.slider').bxSlider({
        auto: true,
        stopAutoOnClick: true,
        pager: true,
        controls: false,
        });
    
})